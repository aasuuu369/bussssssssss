<!DOCTYPE html>
<html>
    <title> Bus Booking </title>
    <style>
.from{
    font-family: 'Poppins', sans-serif;
}
.to{
    font-family: 'Poppins', sans-serif;
}
submit{
    font-family: 'Poppins', sans-serif;
}
        </style>
    <head>
</head>

<body align="center">
    <h1>Book Your Bus</h1>
    <hr>
  <label for="from" class="from">FROM </label>
  <select name="from">
      <option value="1">Vadodara</option>
      <option value="2">Ahmedabad</option>
      <option value="3">Surat</option>
      <option value="4">Rajkot</option>
      <option value="5">Godhra</option>
</select>

<label for = "to" class="to">TO </label>
<select>
<option>Mumbai</option>
<option>Delhi</option>
<option>Udaipur</option>
<option>Kedarnath</option>
<option>Sikkim</option>
</select>


<input type = "submit" id="search" class="search">
</body>
    </html>