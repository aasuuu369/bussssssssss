<!DOCTYPE html>
<html>
    <head>
        <title>Payment Method</title>
<style> 
.tick{
    font-family: 'Poppins', sans-serif;
    line-height:50px;    
     
}
body{
    background-image: url('admin_bg.jpg');
}
h2{
    font-family:Trebuchet MS;
}
.submit{
    background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
}
a{
    color:white;
    text-decoration:none;
}
H1{
    font-family:
}
    </style>
</head>

<body align="center" link="black" alink="black">
    <h1> Online Bus Booking System </h1>
    <hr>
    <br>
    <div class="pymt">
    <h2>Choose Payment Method : </h2><br>
</div>
<div class="tick">
        Net Banking<br>
        Wallet Pay<br>
        Debit/Credit Card<br>
        UPI<br><br>

        <button class="submit">
        <a href="netbanking.html">Net Banking</a>
        </button>

        <button class="submit">
        <a href="wallet.html">Wallet</a>
        </button>

        <button class="submit">
        <a href="ccard.html">D/C Card</a>
        </button>

        <button class="submit">
        <a href="upi.html">UPI</a>
        </button>
</div>
</body>
    </html>