<?php
header("Location: rlogin.php");
?>
