<html>
<head>
<title>Terms & Conditions for Online Bus Booking</title>
</head>
<body>
<?php

echo "Terms andd Conditions forr Online Bus Booking System."
?>
</body>
</html>