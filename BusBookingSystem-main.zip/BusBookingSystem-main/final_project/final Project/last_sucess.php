<html>

<head>
<title>Payment Sucessful</title>
<style>
h1{
    text-align:center;
    margin-top:150px;
    font-family:Helvetica;
    line-height: 100px;
}
a{
    text-decoration:none;
    font-family:tahoma;
    font-size:24px;
    color:black;
}
body{
    background-image: url('admin_bg.jpg');
}
</style>
</head>
<body>
<h1>Payment has been done Successfully!</h1>
<h1>Thank you for Choosing our System<h1>
    <button>
<a href="index.php">Go Back to Homepage </a> 
</button>
</body>
</html>