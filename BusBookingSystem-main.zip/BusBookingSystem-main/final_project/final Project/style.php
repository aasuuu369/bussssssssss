<style type=”text/css”>

body{
  background-color: aqua;

}

ul{

  background-color: blue;
  font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
}

.button{
  background-color: blue;
  height: 100px;
  width: 100px;

}