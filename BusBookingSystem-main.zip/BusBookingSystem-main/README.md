# BusBookingSystem
Online Bus Booking System Project for College Students. A Simple PHP Dynamic Webpage for Students who wants to Build a Bus Booking Project. Full Fledge Working
Bus Booking website.

  STEPS TO INSTALL 

1. Download Project Source Code from here.
2. Paste the Folder in your xampp/htdocs/
3. Open your Localhost SQL and create Database Name as login_register_pure_coding
4. Then Import my Database File in Above DB.
5. That's it! Start your XAMPP Apache & SQL Server and Book your Bus...

NOTE:- 
Admin Registration is not Available on Webpage, You have to Manually Add Admin Credentials from the Database.
DEFAULT ADMIN ID PASS : 
  Username : chetan
  Password : chetan
  
 Drop a Like here and Do Subscribe my Youtube Channel : Cricket Guruji. 
